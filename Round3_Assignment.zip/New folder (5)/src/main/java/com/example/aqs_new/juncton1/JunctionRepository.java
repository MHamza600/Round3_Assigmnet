package com.example.aqs_new.juncton1;

import com.example.aqs_new.hospital1.Hospital;
import org.springframework.data.jpa.repository.JpaRepository;

public interface JunctionRepository extends JpaRepository<Junction,Long> {
}
