package com.example.aqs_new.portalController;

import com.example.aqs_new.hospital1.Hospital;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;


import javax.swing.text.html.HTML;
import javax.swing.text.html.HTMLDocument;

@RestController
public class PortalController
{

}
