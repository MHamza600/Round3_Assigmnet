package com.example.aqs_new.daigonose1;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DaigonosRepository extends JpaRepository<Daigonos,Long> {


}

