package com.example.aqs_new.response;

public class Respone {


        String Response;

        public String getResponse() {
            return Response;
        }

        public void setResponse(String response) {
            Response = response;
        }





}
