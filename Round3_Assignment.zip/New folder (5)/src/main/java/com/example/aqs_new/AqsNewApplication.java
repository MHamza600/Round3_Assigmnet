package com.example.aqs_new;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AqsNewApplication {

    public static void main(String[] args) {
        SpringApplication.run(AqsNewApplication.class, args);
    }

}

